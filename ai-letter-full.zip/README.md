
# AI Letter Full (Steps 1-3)

This Next.js project contains the UI for Steps 1-3:
- 3D-feel intro carousel (Birthday, Love, Marriage)
- Language selection (Malayalam, English, Hindi)
- Actor selection (3 per language) with placeholder images
- Tailwind, Framer Motion, Keen Slider, Canvas Confetti

## Run locally
1. npm install
2. npm run dev
Open http://localhost:3000

## Deploy on Vercel
Upload this project to a GitHub repo and import it to Vercel, or directly upload the unzipped project in Vercel's upload flow.
